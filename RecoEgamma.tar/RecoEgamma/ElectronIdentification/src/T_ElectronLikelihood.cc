
#include "FWCore/Utilities/interface/typelookup.h"
#include "RecoEgamma/ElectronIdentification/interface/ElectronLikelihood.h"
TYPELOOKUP_DATA_REG( ElectronLikelihood );
